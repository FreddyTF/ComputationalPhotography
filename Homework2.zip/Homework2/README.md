# Structure

The main code is in the folder code.

The tests folder contains a test to compare the unsharping masking between spatial and frequency domain.

